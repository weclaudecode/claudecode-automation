# Kiro-CLI Technical Narrative: Agentic Coding for a One-Man Team

## Introduction

This document tells the story of how kiro-cli transformed a solo developer's ability to build, maintain, and deploy a complex multi-repo AWS dashboard platform. The project — powerpipe-dashboard — spans 4 repositories, scans 9 AWS accounts, generates FinOps reports, detects infrastructure drift, and serves interactive dashboards on EKS. All developed and operated by one person.

**The challenge:** A system this complex normally requires a team. One person can't hold all the conventions, security rules, deployment patterns, and operational procedures in their head simultaneously. Every context switch loses knowledge. Every new session starts from zero.

**The solution:** Kiro-cli as a persistent, context-aware development partner. Not just autocomplete — a full development workflow with memory, rules, specialised agents, safety guardrails, and automation.

---

## 1. Steering: Injecting Project DNA Into Every Session

### The Problem

Every time a new session started, the AI had no idea about:
- Our branch naming conventions (`feature/CHR-XXXXX-slug`)
- That we use Vault for AWS auth, never raw keys
- That Kyverno policies require specific labels on every K8s resource
- That pushing to main is forbidden — always MR
- That `powerpipe dashboard list` must pass before any commit

Without this context, the AI would suggest wrong patterns, use `git push origin main`, forget security constraints, or generate Kubernetes manifests that Kyverno would reject.

### The Solution

Steering files — markdown documents in `.kiro/steering/` that are automatically loaded into every session's context window. They act as persistent project rules that the agent follows without being reminded.

### What We Built

```
.kiro/steering/
├── project-structure.md          # Multi-repo architecture, data flow, accounts
├── account-onboarding.md         # Step-by-step for adding new AWS accounts
├── kyverno-policies.md           # K8s admission policies (labels, non-root)
├── terraform-conventions.md      # IaC patterns: naming, tagging, backend
├── terragrunt-conventions.md     # DRY IaC: directory layout, dependencies
├── gitlab-ci-conventions.md      # CI patterns: Vault auth, image pins, stages
├── gitops-workflow.md            # Branch strategy, MR flow, deploy triggers
├── secrets-handling.md           # Never hardcode keys, Vault-only, masked vars
├── development-workflow.md       # Feature lifecycle with human gates
├── powerpipe-verification.md     # Always run dashboard list after .pp changes
├── desired-state-workflow.md     # Excel → YAML → SQL pipeline
├── desired-state-download.md     # Confluence → Excel download automation
├── pilot-deployment-lessons.md   # Hard-won lessons from first deploy
└── powerpipe-official-repo.md    # Reference for HCL semantics
```

### Concrete Example: Kyverno Policies

```markdown
# Kyverno Cluster Policies (from .kiro/steering/kyverno-policies.md)

## Mandatory Labels
Every Kubernetes resource MUST have these labels:
- asx_application: powerpipe-reports
- asx_environment: <env_name>
- asx_data_classification: internal

## Security Context — Run as Non-Root
All pods MUST run as non-root:
- spec.securityContext.runAsNonRoot: true
- spec.securityContext.runAsUser: 1000
- Every container must also set these independently
```

**Without steering:** The AI generates a Deployment without labels → Kyverno rejects it → we debug for 20 minutes.

**With steering:** The AI includes `mandatoryLabels` and `runAsUser: 1000` automatically, every time.

### Outcome

- Zero Kyverno rejections since adding the steering file
- Consistent branch naming across all sessions
- No accidental pushes to main
- Every `kubectl` suggestion goes through the pipeline, not direct commands

---

## 2. Skills: Teaching Kiro What It Doesn't Know

### The Problem

Kiro (and the underlying LLM) had no knowledge of:
- **Powerpipe HCL syntax** — a niche dashboard-as-code tool with its own block types, 12-column grid system, and query conventions
- **Steampipe's embedded Postgres mode** — our architecture uses pre-computed tables, not live plugin queries
- **Our specific CI architecture** — dynamically generated child pipelines per AWS account
- **FinOps cost formulas** — `hourly_cost × (730 - uptime_hrs × 4.33)` for scheduling savings

Without this knowledge, the AI would hallucinate HCL syntax, suggest wrong Steampipe patterns, or break the CI pipeline.

### The Solution

Skills — structured knowledge packages with YAML frontmatter that are loaded **on demand** (not always, like steering). Each skill has a description that tells kiro WHEN to load it, plus reference documents, assets, and scripts.

### What We Built

```
.kiro/skills/
├── powerpipe/
│   ├── SKILL.md                      # Trigger: mentions of HCL dashboards, .pp files
│   ├── references/
│   │   ├── hcl-syntax.md             # Block types, width system, containers
│   │   ├── sql-patterns.md           # CTEs, JSONB, pre-computed tables
│   │   ├── graphs-and-flows.md       # Node/edge relationship diagrams
│   │   ├── running-and-exporting.md  # CLI commands, server mode
│   │   └── troubleshooting.md        # Empty panels, parse errors, stale data
│   └── assets/
│       ├── mod-skeleton/             # Complete starter mod template
│       ├── create_resources_table.sql
│       └── refresh_account.sql
├── steampipe/
│   ├── SKILL.md                      # Trigger: scan results, SQL loading, DB issues
│   ├── references/
│   │   ├── local-development.md      # Service start, port 9193, psql
│   │   ├── ci-scan-pipeline.md       # Per-account scan flow
│   │   ├── container-lifecycle.md    # Pod startup, S3 sync, refresh
│   │   └── query-patterns.md        # Table schemas, common JOINs
│   ├── assets/
│   │   ├── load-local-data.sh
│   │   └── scan-pipeline-child.yml
│   └── scripts/
│       └── setup-steampipe.sh
├── finops-cost-scan/
│   └── SKILL.md                      # Full cost scan automation guide
├── terraform-aws/
│   ├── SKILL.md
│   ├── references/ (6 files)
│   ├── assets/ (8 files + module-skeleton/)
│   └── scripts/
├── aws-solution-architect/
│   ├── SKILL.md
│   ├── references/ (10 files)
│   ├── assets/ (4 files)
│   └── scripts/
├── security-code-reviewer/
│   └── SKILL.md                      # Security review checklist
└── gitlab-pipeline/
    └── SKILL.md                      # CI architecture patterns
```

### Concrete Example: Powerpipe Skill

The SKILL.md frontmatter tells kiro when to activate:

```yaml
---
name: powerpipe
description: "Use when building, modifying, or troubleshooting Powerpipe dashboards
  and mods — covers HCL dashboard/query/graph syntax... Use this skill whenever the
  user mentions powerpipe, steampipe dashboards, .pp files, or wants to visualize
  cloud resources interactively."
---
```

When triggered, kiro loads the core knowledge:
- Dashboards use a 12-column CSS grid
- Every query starts with `${local.all_resources_cte}`
- Cards return `value`, `label`, `type` (ok/alert/info)
- Tables support `column` blocks with `href` for navigation

And can drill into references on demand (HCL syntax details, SQL patterns, troubleshooting).

### The Difference

**Before skills (early project):**
```
User: Create a card showing total EC2 instances
AI: dashboard "ec2_count" {
       card {
         sql = "SELECT count(*) FROM aws_ec2_instance"  ← WRONG: live table, not pre-computed
       }
     }
```

**After skills:**
```
User: Create a card showing total EC2 instances
AI: query "card_total_ec2" {
       sql = <<-EOQ
         ${local.all_resources_cte}
         select count(*) as value, 'EC2 Instances' as label
         from all_resources
         where service = 'EC2' and resource_type = 'Instance'
       EOQ
     }
```

### Outcome

- Correct HCL generated on first attempt (no more hallucinated syntax)
- Pre-computed table pattern used consistently
- CI pipeline knowledge prevents broken child pipelines
- Cost formulas are mathematically correct every time

---

## 3. Agents: Right Tool for the Right Job

### The Problem

A single general-purpose agent trying to do everything creates issues:
- **Context pollution** — loading Terraform conventions when writing HCL dashboards
- **Wrong tools available** — write access when you only need a security review
- **No specialisation** — the same prompt tries to be a developer, reviewer, and architect
- **Permission sprawl** — every agent can modify any file, run any command

### The Solution

Purpose-built agents with:
- Scoped tool access (what they CAN do)
- Permission boundaries (what files they can write)
- Focused system prompts (what they SHOULD do)
- Safety hooks (what they MUST NOT do)

### What We Built

| Agent | Purpose | Tools | Key Constraint |
|-------|---------|-------|----------------|
| `feature-developer` | Build features with workflow gates | read, write, shell, subagent | Write scoped to `powerpipe/**` only |
| `code-reviewer` | Pre-MR code review | read, grep, glob, shell | `denyByDefault` — only git diff/log/show + dashboard list |
| `security-auditor` | Security review of changes | read, shell | No write access. Hands off fixes. |
| `terraform-reviewer` | IaC review | read, shell | No write. Reviews only. |
| `gitlab-ci-engineer` | CI/CD pipeline work | read, write, shell | Focused on .gitlab-ci.yml patterns |
| `jira-agent` | Ticket management | read, shell | Hook blocks all delete operations |
| `aws-architect` | Architecture design | read, MCP | Read-only. Produces docs, not code. |

### Concrete Example: feature-developer Agent

```json
{
  "name": "feature-developer",
  "tools": ["read", "write", "shell", "grep", "glob", "subagent", "todo", "knowledge", "thinking"],
  "allowedTools": ["read", "grep", "glob"],
  "toolsSettings": {
    "write": {
      "allowedPaths": ["./powerpipe-dashboard/powerpipe/**", "./.kiro/**"],
      "deniedPaths": ["./powerpipe-dashboard/.gitlab-ci.yml"]
    },
    "shell": {
      "allowedCommands": [
        "git status", "git diff.*", "git log.*", "git branch.*",
        "git checkout main", "git checkout -b .*", "git checkout feature/.*",
        "git pull.*", "git add .*", "git commit.*",
        "git push -u origin feature/.*",
        "powerpipe dashboard list", "cd .* && powerpipe dashboard list",
        "glab mr create.*", "twg jira.*"
      ],
      "autoAllowReadonly": true
    }
  },
  "hooks": {
    "agentSpawn": [{"command": "git branch --show-current && git status --short"}],
    "preToolUse": [{"matcher": "shell", "command": "python3 .kiro/hooks/git-safety-guard.py"}]
  },
  "keyboardShortcut": "ctrl+shift+f",
  "welcomeMessage": "Ready for feature development. Use @feature-workflow to start a guided flow, or describe what you'd like to build."
}
```

**What this achieves:**
- Can write dashboard HCL files — cannot touch `.gitlab-ci.yml`
- Can run `git commit`, `git push -u origin feature/...` — but the hook blocks `git push origin main`
- Can run `twg jira` and `glab mr create` — full workflow automation
- Shows current branch on startup — instant context awareness
- Has `subagent` tool — can delegate to `code-reviewer` for pre-MR review

### Agent Composition via Subagents

The `feature-developer` agent orchestrates:
1. Implements the feature itself (write access)
2. Delegates review to `code-reviewer` (read-only, focused critique)
3. If review passes, proceeds to commit/push

This mirrors a real team: developer writes, reviewer reviews, neither has the other's permissions.

### Outcome

- No accidental modifications to CI pipeline from the dashboard agent
- Security reviews are structurally unable to "fix it themselves" (no write access)
- Feature development automatically gets branch context on startup
- One keyboard shortcut (`ctrl+shift+f`) to enter development mode

---

## 4. Hooks: Automated Safety Guardrails

### The Problem

Even with the best intentions and clear steering rules, mistakes happen:
- Accidentally running `git push origin main` instead of the feature branch
- Force-pushing and losing history
- Deleting Jira tickets instead of updating them
- Making write AWS API calls from a read-only context

One wrong command can take hours to recover from.

### The Solution

Hooks — Python scripts that intercept tool calls BEFORE they execute. They receive the tool invocation as JSON, evaluate it against safety rules, and can **block** execution (exit code 2) with an explanation sent back to the AI.

### What We Built

```
.kiro/hooks/
├── git-safety-guard.py      # Blocks: push to main, force push, reset --hard
├── aws-readonly-guard.py    # Blocks: any non-read AWS API call
└── jira-no-delete-guard.py  # Blocks: ticket/comment deletion
```

### Concrete Example: git-safety-guard.py

```python
#!/usr/bin/env python3
"""Hook: Block dangerous git operations. Exit 2 to block, 0 to allow."""
import json, re, sys

BLOCKED_PATTERNS = [
    r"git\s+push\s+.*\b(main|master)\b",   # push to main/master
    r"git\s+push\s+.*--force",              # force push (includes --force-with-lease)
    r"git\s+push\s+.*-[a-z]*f",             # combined short flags (-f, -fu)
    r"git\s+reset\s+--hard",                # hard reset
    r"git\s+clean\s+-f",                    # force clean
    r"git\s+branch\s+-D\b",                 # force delete branch
]

def main():
    event = json.load(sys.stdin)
    if event.get("tool_name") not in ("shell", "execute_bash"):
        sys.exit(0)
    tool_input = event.get("tool_input")
    if not tool_input or not isinstance(tool_input, dict):
        sys.exit(0)
    cmd = tool_input.get("command", "").replace("\n", " ")
    if "git" not in cmd:
        sys.exit(0)
    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, cmd):
            print(f"BLOCKED: Dangerous git operation detected. "
                  f"Pattern: '{pattern}' matched. "
                  f"Use a feature branch and MR instead.", file=sys.stderr)
            sys.exit(2)  # ← Exit 2 = BLOCK the tool call
    sys.exit(0)  # ← Exit 0 = ALLOW

if __name__ == "__main__":
    main()
```

### How It Works in Practice

```
Agent: I'll push the changes now.
       → shell: git push origin main

Hook intercepts → BLOCKED: push to main detected
                → stderr returned to agent

Agent: I can't push to main directly. Let me push to the feature branch instead.
       → shell: git push -u origin feature/CHR-12345-resource-summary
       
Hook intercepts → allowed (no blocked patterns matched)
```

The agent **self-corrects** because the hook's error message tells it why the action was blocked and what to do instead.

### Hook Configuration in Agent JSON

```json
"hooks": {
  "preToolUse": [
    {
      "matcher": "shell",
      "command": "python3 .kiro/hooks/git-safety-guard.py"
    }
  ]
}
```

The `matcher` field ensures the hook only runs for shell commands — not for file reads or searches.

### Outcome

- Zero accidental pushes to main since deployment
- Zero force-push incidents
- Zero Jira ticket deletions
- AWS accounts protected from write operations in read-only contexts
- Agent learns from blocks and adapts (doesn't retry the same blocked action)

---

## 5. Permissions & Trust: Reducing Friction Without Reducing Safety

### The Problem

Two extremes, both bad:
1. **Too much prompting** — the agent asks permission for every `git status`, every file read, every grep. Workflow grinds to a halt.
2. **Too much trust** — the agent auto-approves everything, including destructive operations. Accidents happen.

### The Solution

Layered trust configuration that auto-approves safe operations and gates dangerous ones:

| Layer | What it controls | Example |
|-------|-----------------|---------|
| `allowedTools` | Which tools never prompt | `["read", "grep", "glob"]` — reading is always safe |
| `toolsSettings.write.allowedPaths` | Which files can be written without prompting | `["./powerpipe-dashboard/powerpipe/**"]` |
| `toolsSettings.write.deniedPaths` | Which files ALWAYS require approval | `["./.gitlab-ci.yml"]` |
| `toolsSettings.shell.allowedCommands` | Which commands auto-approve | `["git status", "powerpipe dashboard list"]` |
| `toolsSettings.shell.autoAllowReadonly` | Auto-approve read-only commands | `ls`, `cat`, `grep` — no risk |
| `toolsSettings.shell.denyByDefault` | Block all commands not explicitly allowed | Used on `code-reviewer` — can only run `git diff` |

### Concrete Example: The Trust Gradient

```json
// feature-developer: CAN write dashboards, CAN'T write CI
"toolsSettings": {
  "write": {
    "allowedPaths": ["./powerpipe-dashboard/powerpipe/**"],
    "deniedPaths": ["./powerpipe-dashboard/.gitlab-ci.yml"]
  }
}

// code-reviewer: CAN'T write anything, CAN only run specific commands
"toolsSettings": {
  "shell": {
    "allowedCommands": ["git diff.*", "git log.*", "powerpipe dashboard list"],
    "denyByDefault": true
  }
}

// jira-agent: CAN run twg commands, CAN'T delete anything (hook enforced)
"hooks": {
  "preToolUse": [{"matcher": "shell", "command": "python3 .kiro/hooks/jira-no-delete-guard.py"}]
}
```

### The Result in Practice

When using `feature-developer`:
- Reading files: ✅ instant (no prompt)
- Searching code: ✅ instant
- Writing a new `.pp` file: ✅ auto-approved (matches `allowedPaths`)
- Running `powerpipe dashboard list`: ✅ auto-approved (matches `allowedCommands`)
- Running `git push -u origin feature/...`: ⚠️ prompts for approval (not in allowedCommands)
- Running `git push origin main`: 🚫 blocked by hook (never reaches prompt)
- Writing `.gitlab-ci.yml`: 🚫 blocked by deniedPaths

### Outcome

- 80% fewer approval prompts during normal development
- Dangerous operations are structurally impossible, not just "strongly discouraged"
- Each agent has exactly the permissions its role requires — no more, no less

---

## 6. Context Management: Skills vs Steering

### The Problem

Context windows are finite. Loading everything into every session wastes tokens and confuses the model with irrelevant information. But loading too little means the agent lacks critical knowledge.

### The Solution

Two loading strategies for two types of knowledge:

| Type | Loading | Use For | Example |
|------|---------|---------|---------|
| **Steering** (`file://`) | Always loaded | Rules that apply to EVERY interaction | Branch conventions, security rules, verification requirements |
| **Skills** (`skill://`) | On-demand | Domain knowledge needed only for specific tasks | Powerpipe HCL syntax, Terraform patterns, FinOps formulas |

### How It Works

**Steering files** — their full content is injected into context at session start:
```json
"resources": [
  "file://.kiro/steering/development-workflow.md",     // Always loaded: 81 lines
  "file://.kiro/steering/project-structure.md",         // Always loaded: 130 lines
  "file://.kiro/steering/powerpipe-verification.md"     // Always loaded: 20 lines
]
```

**Skills** — only their name + description are loaded initially. Full content loads when triggered:
```json
"resources": [
  "skill://.kiro/skills/powerpipe/SKILL.md",    // Initially: just the frontmatter
  "skill://.kiro/skills/steampipe/SKILL.md"     // Full content loaded when relevant
]
```

### The Economics

| What | Lines | When loaded |
|------|-------|-------------|
| `development-workflow.md` | 81 | Every session (essential rules) |
| `project-structure.md` | 130 | Every session (multi-repo context) |
| Powerpipe SKILL.md | 7,200 chars | Only when building dashboards |
| Steampipe SKILL.md | 11,161 chars | Only when debugging DB/scans |
| Terraform SKILL.md | 6,745 chars | Only when working on IaC |

A typical dashboard development session loads ~230 lines of steering + the powerpipe skill. A Terraform session loads the same steering + terraform skill instead. No wasted context.

### Outcome

- Steering ensures consistency without being asked
- Skills provide depth without bloating every session
- The right knowledge activates at the right time
- Context budget is spent on the current task, not irrelevant domains

---

## 7. Workflow Automation: From Idea to Deployed Dashboard

### The Problem

The feature development lifecycle has 8+ steps, each with potential for human error:
1. Research existing patterns
2. Plan the implementation
3. Create a Jira ticket
4. Create a branch
5. Implement the feature
6. Verify locally
7. Get code review
8. Commit, push, create MR
9. Update Jira

Doing this manually means: forgetting to create the ticket first, using wrong branch naming, skipping verification, pushing untested code, or creating an MR without updating Jira.

### The Solution

A **prompt template** (`@feature-workflow`) that orchestrates the entire flow, combined with a **purpose-built agent** (`feature-developer`) that has the tools, permissions, and hooks to execute it safely.

### The Workflow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  @feature-workflow prompt                                        │
│  (orchestrates the sequence, defines human gates)               │
├─────────────────────────────────────────────────────────────────┤
│  feature-developer agent                                         │
│  ├── Tools: read, write, shell, subagent, todo                  │
│  ├── Permissions: write only to powerpipe/**, deny .gitlab-ci   │
│  ├── Hooks: git-safety-guard (preToolUse on shell)              │
│  ├── agentSpawn: shows current branch + git status              │
│  └── Resources: development-workflow + powerpipe skill          │
├─────────────────────────────────────────────────────────────────┤
│  code-reviewer agent (delegated via subagent)                    │
│  ├── Tools: read, grep, glob, shell (denyByDefault)             │
│  ├── Can only run: git diff, git log, powerpipe dashboard list  │
│  └── Output: LGTM / CHANGES REQUESTED                          │
└─────────────────────────────────────────────────────────────────┘
```

### Human Gates

Every irreversible action pauses for explicit approval:

| Gate | What's shown | Why it matters |
|------|-------------|----------------|
| 🔒 Plan approval | Files to change, expected outcome | Prevents wrong direction |
| 🔒 Jira creation | Ticket title, description, fields | Prevents tracking gaps |
| 🔒 Branch creation | Branch name | Prevents naming mistakes |
| 🔒 Pre-review | git diff summary | Catches issues before review |
| 🔒 Post-review | Findings from code-reviewer | Decides fix vs proceed |
| 🔒 Push | Commit message + file list | Last chance before sharing |
| 🔒 MR creation | MR title + description | Controls what reviewers see |

### The Deploy Pipeline (Automatic After MR Merge)

```
MR merged to main
  → publish-mod: syncs powerpipe/ to S3 (mod bucket)
  → trigger-refresh: triggers powerpipe-deploy with REFRESH_DATA=true
    → powerpipe-deploy: kubectl rollout restart
      → pod pulls new dashboard from S3
        → dashboard live in browser
```

No manual deployment step. Merge = deploy.

### Outcome

- Consistent execution of the full lifecycle every time
- No forgotten steps (Jira, verification, review)
- Safety hooks prevent the 3 most dangerous mistakes
- Subagent review catches issues before they reach MR
- Pipeline handles deployment — zero manual kubectl

---

## 8. Live Demo: Adding a Resource Count Summary Dashboard

### The Feature

A "Resource Count Summary" dashboard showing:
- **Row 1:** Cards — Total Resources across all accounts, Total EC2, Total RDS, Total EKS, Total EFS
- **Row 2:** Table — Per-account breakdown (Account | EC2 | RDS | EKS | EFS | LB | Total)
- **Row 3:** Table — Per-environment breakdown (Environment | EC2 | RDS | EKS | EFS | Total)

### Files Created

```
powerpipe-dashboard/powerpipe/
├── dashboards/resource_count_summary.pp    # Dashboard layout (cards + tables)
└── queries/resource_count_summary.pp       # SQL queries using all_resources_cte
```

### The Workflow in Action

```
1. Switch to feature-developer agent (ctrl+shift+f)
   → agentSpawn hook shows: Branch: main, Status: clean

2. Invoke @feature-workflow
   → Step 1: Research existing patterns (reads finops_summary.pp, locals.pp)
   → Plan presented: 2 new files, no existing files modified

3. 🔒 Plan approved

4. → Step 2: Jira ticket created (CHR-XXXXX)
   🔒 Ticket approved

5. → Step 3: Branch created (feature/CHR-XXXXX-resource-count-summary)
   🔒 Branch confirmed

6. → Step 4: Implementation
   - Creates dashboard HCL with cards + tables
   - Creates queries using ${local.all_resources_cte}
   - Runs: powerpipe dashboard list → exits 0 ✅
   🔒 Diff shown, approved

7. → Step 5: Subagent code-reviewer activated
   - Reviews HCL structure, SQL validity, conventions
   - Verdict: LGTM
   🔒 User approves proceeding

8. → Step 6: Commit & push
   - git add powerpipe/dashboards/resource_count_summary.pp
   - git add powerpipe/queries/resource_count_summary.pp
   - git commit -m "feat(CHR-XXXXX): add resource count summary dashboard"
   - git push -u origin feature/CHR-XXXXX-resource-count-summary
   🔒 Push approved

9. → Step 7: MR created via glab
   🔒 MR link shown

10. → Step 8: Jira updated with MR link

11. MR merged → pipeline runs → dashboard appears in production
```

### What the Demo Shows

| Kiro Feature | Where It's Visible |
|-------------|-------------------|
| **Steering** | Agent knows branch naming, commit format, verification step |
| **Skills** | Correct HCL syntax generated (12-col grid, named queries, CTE) |
| **Agents** | feature-developer writes, code-reviewer reviews (separate permissions) |
| **Hooks** | git-safety-guard blocks any push to main |
| **Permissions** | Write scoped to powerpipe/**, .gitlab-ci.yml denied |
| **Context** | Steering loaded always, powerpipe skill loaded on demand |
| **Workflow** | 8-step flow with human gates, zero missed steps |
| **Automation** | MR merge → pipeline → S3 → pod refresh → live dashboard |

---

## Summary: The One-Man Team Multiplier

| Before Kiro | After Kiro |
|------------|-----------|
| Forgot conventions between sessions | Steering enforces them automatically |
| Hallucinated Powerpipe syntax | Skills provide verified patterns |
| One agent trying to do everything | Specialised agents with scoped access |
| Accidental destructive operations | Hooks block before execution |
| Constant approval prompts | Trust layers auto-approve safe operations |
| Context window wasted on irrelevant info | Skills load on-demand, steering stays lean |
| 8-step manual process with missed steps | Automated workflow with human gates |
| Manual deployment after merge | Pipeline auto-deploys in minutes |

**The bottom line:** One developer, 4 repositories, 9 AWS accounts, 6 dashboards, full CI/CD pipeline — delivered and maintained with kiro-cli as the development partner. Not replacing the developer's judgment, but amplifying their capacity by handling the mechanical parts while they focus on design decisions.
