# Claude Code Best Practices — Deck Plan

Audience: experienced devs leveling up. Educational. Topic-modular (1–3 slides per topic; individual slides reusable).
Motion: rich animated diagrams for — context window filling, explore→plan→code→commit, verification loop, fan-out.

## Visual system
- Vibe: refined dev/technical + warm editorial. Two backgrounds only.
  - PAPER (light): warm cream bg, ink text — content slides
  - INK (dark): warm near-black bg, cream text — section dividers + animated diagrams
- Fonts: Space Grotesk (display + body), JetBrains Mono (labels/code/kickers)
- Accent: clay/terracotta (sparingly). Sage green = "pass/verified" states only.
- Kicker labels in mono, uppercase, letter-spaced. Slide numbers bottom-right.
- Title style: short topic noun-phrases, sentence-ish caps. Chapter-like.

## Title sequence (chapters)
01 Best Practices for Claude Code (cover)
02 Agentic coding changes how you work (framing)
-- I. THE CORE CONSTRAINT --
03 The one constraint: the context window
04 How the context window fills [ANIM: fill bar]
05 Managing context aggressively
-- II. VERIFICATION --
06 Give Claude a way to verify its work
07 The verification loop [ANIM: loop]
08 Four ways to gate the stop
09 Show evidence, not assertions
-- III. WORKFLOW --
10 Explore, then plan, then code
11 The four-phase workflow [ANIM: E→P→C→Commit]
12 When to skip the plan
-- IV. PROMPTING --
13 Provide specific context
14 Vague vs. specific (before/after)
15 Provide rich content (@ files, images, URLs, pipe)
-- V. CONFIGURE THE ENVIRONMENT --
16 Configure your environment (map)
17 Write an effective CLAUDE.md
18 CLAUDE.md: include vs. exclude
19 Where CLAUDE.md lives
20 Configure permissions
21 Extend: CLI tools, MCP, hooks
22 Skills & subagents
-- VI. COMMUNICATE --
23 Ask codebase questions
24 Let Claude interview you
-- VII. MANAGE THE SESSION --
25 Course-correct early and often
26 Rewind with checkpoints
-- VIII. AUTOMATE & SCALE --
27 Automate and scale (map)
28 Run multiple sessions (Writer/Reviewer)
29 Fan out across files [ANIM: fan-out]
30 Add an adversarial review step
-- IX. WISDOM --
31 Common failure patterns
32 Develop your intuition (close)

## Animated diagrams (CSS keyframes, looping, static markup)
1. Context fill: token bar filling 0→100, hot zone near top, "perf degrades" marker, /clear resets — loop.
2. Verify loop: 4-node ring (do → check → read → iterate) with traveling pulse + PASS exit.
3. Workflow: 4 nodes Explore→Plan→Code→Commit, pulse travels, plan-mode gate.
4. Fan-out: 1 source → N parallel workers, staggered pulses down branches.
